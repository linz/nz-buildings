03/11/2025

compare_related_turned_off.sql is a version of compare.sql
that has "related" components commented out.

This change was made in the Production database becase the
RECURSIVE function for "related" buildings was taking a lot
of time to run, and preventing the completion of the compare
process.

This change was attempted in this GitHub Repo but it was
difficult to change the Tests correctly to identify the
relevant buildings as "added" and "removed" instead of
"related".  This has been put on hold for now.

